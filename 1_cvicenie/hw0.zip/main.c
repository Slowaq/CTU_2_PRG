#include <stdio.h>
 
int main()
{
    printf("Hello PRG!\n");
    return 0;
}